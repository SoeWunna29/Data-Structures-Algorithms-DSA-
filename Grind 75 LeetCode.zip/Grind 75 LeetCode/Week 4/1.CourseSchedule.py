from typing import List


class Solution:
    def can_finish(self, num_courses: int, prerequisites: List[list[int]]) -> bool:
        # map each course to prereq list
        pre_map = {i: [] for i in range(num_courses)}
        for crs, pre in prerequisites:
            pre_map[crs].append(pre)

        # visit_set = all courses along the curr DFS path
        visit_set = set()

        def dfs(crs):
            if crs in visit_set:
                return False
            if pre_map[crs] == []:
                return True

            visit_set.add(crs)
            for pre in pre_map[crs]:
                if not dfs(pre): return False
            visit_set.remove(crs)
            pre_map[crs] =[]
            return True

        for crs in range(num_courses):
            if not dfs(crs): return False
        return True


obj = Solution()
courses = [[0, 1], [0, 2], [1, 3], [1, 4], [3, 4]]
print(obj.can_finish(5, courses))
