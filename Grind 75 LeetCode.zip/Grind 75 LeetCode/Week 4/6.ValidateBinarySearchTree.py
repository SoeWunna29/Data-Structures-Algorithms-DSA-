class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


class solution:
    def is_valid_bst(self, root: TreeNode) -> bool:
        def valid(node, left, right):
            if not node:
                return True
            if not(right > node.val > left):
                return False

            return valid(node.left, left, node.val) and valid(node.right, node.val, right)
        return valid(root, float("-int"), float("inf"))
