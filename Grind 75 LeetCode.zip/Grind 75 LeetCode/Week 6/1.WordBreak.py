from typing import List


class Solution:
    def word_break(self, s: str, word_dict: List[str]) -> bool:

        dp = [False] * (len(s) + 1)
        dp[len(s)] = True

        for i in range(len(s) - 1, -1, -1):
            for w in word_dict:
                if (i + len(w)) <= len(s) and s[i: i + len(w)] == w:
                    dp[i] = dp[i + len(w)]
                if dp[i]:
                    break

        return dp[0]


obj = Solution()
words = ["Soe", "Wunna"]
print(obj.word_break("SoeWunna", words))
