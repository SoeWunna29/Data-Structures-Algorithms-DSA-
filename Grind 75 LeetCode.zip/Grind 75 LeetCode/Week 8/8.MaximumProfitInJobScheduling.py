from bisect import bisect_left
from functools import lru_cache
from typing import List


class Solution:
    def job_scheduling(self, start_time: List[int], end_time: List[int], profit: List[int]) -> int:
        n = len(start_time)
        jobs = list(zip(start_time, end_time, profit))
        jobs.sort()
        start_time.sort()

        @lru_cache(None)
        def rec(i):
            if i == n:
                return 0
            j = bisect_left(start_time, jobs[i][1])
            one = jobs[i][2] + rec(j)
            two = rec(i + 1)
            return max(one, two)
        return rec(0)

# Binary Search
