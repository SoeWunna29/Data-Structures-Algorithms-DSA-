import heapq


class Solution:
    def k_closet(self, points: List[List[int]], k: int) -> list[list[int]]:
        min_heap =[]
        for x, y in points:
            dist = (x ** 2) + (y ** 2)
            min_heap.append([dist, x, y])

        heapq.heapify(min_heap)
        res = []
        while k > 0:
            res.append(heapq.heappop(min_heap))
            res.append([x, y])
            k -= 1

        return res
