from collections import Counter


class Solution:
    def is_anagram(self, s: str, t: str) -> bool:
        # return Counter(s) == Counter(t)  # using built-in function

        if len(s) != len(t):
            return False

        count_s, count_t = {}, {}

        # count number of each character in both strings
        for i in range(len(s)):
            count_s[s[i]] = 1 + count_s.get(s[i], 0)  # setting value as zero
            count_t[s[i]] = 1 + count_t.get(s[i], 0)
        for c in count_s:
            if count_s[c] != count_t.get(c, 0):  # to avoid error
                return False

        return True


obj = Solution()
str1 = "abcdefg"
str2 = "gfedcba"
print(obj.is_anagram(str1, str2))

# Follow-up
# sort two string and compare to avoid using extra space but big O should also be considered
