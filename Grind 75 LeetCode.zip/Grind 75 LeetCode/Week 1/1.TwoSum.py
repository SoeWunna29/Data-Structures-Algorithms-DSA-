from typing import List


class Solution:
    def two_sum(self, nums: List[int], target: int) -> List[int]:
        previous_map = {}  # val : index

        for i, n in enumerate(nums):  # i is index and n is value is list
            difference = target - n
            if difference in previous_map:
                return [previous_map[difference], i]  # returning indexes

            previous_map[n] = i  # adding value n to map at index i


obj = Solution()
nums = [1, 2, 5, 3]
target = 4
print(obj.two_sum(nums, target))

# Time - O(n), Space - O(n)
