class Solution:
    def is_valid(self, s: str) -> bool:
        stack = []
        close_to_open = {")": "(", "]": "[", "}": "{"}  # key is closing parentheses

        for parenthesis in s:
            if parenthesis in close_to_open:
                # Stack must not be empty and
                # Last item in the stack is the value of closing parenthesis key
                if stack and stack[-1] == close_to_open[parenthesis]:
                    stack.pop()  # Remove the last item in the list
                else:
                    return False
            else:
                stack.append(parenthesis)

        return True if not stack else False  # return True only if the stack is empty


obj = Solution()
s = "(){}[]"
print(obj.is_valid(s))

# Time - O(n), Space - O(n)
