class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


class Solution:
    def merge_two_list(self, l1: ListNode, l2: ListNode) -> ListNode:
        dummy = ListNode()  # Creating a dummy node for edge case, empty string
        tail = dummy

        while l1 and l2:  # while l1 and l2 is not empty
            if l1.val < l2.val:
                tail.next = l1  # adding after dummy node
                l1 = l1.next  # next node in the list
            else:
                tail.next = l2
                l2 = l2.next
            tail = tail.next

        if l1:
            tail.next = l1
        elif l2:
            tail.next = l2

        return dummy.next

# Two lists are linked lists.
