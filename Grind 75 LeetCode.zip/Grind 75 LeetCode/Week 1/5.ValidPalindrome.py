class Solution:
    def is_palindrome(self, s: str) -> bool:
        left, right = 0, len(s) - 1

        while left < right:
            while left < right and not self.alpha_num(s[left]):
                left += 1
            while left < right and not self.alpha_num(s[right]):
                right -= 1
            if s[left].lower() != s[right].lower():
                return False
            left, right = left + 1, right - 1
        return True

    def alpha_num(self, c):  # helper function
        return (ord('A') <= ord(c) <= ord('Z') or
         ord('a') <= ord(c) <= ord('z') or
         ord('0') <= ord(c) <= ord('9'))  # ord gets ASCII value


obj = Solution()
s = "aca"
print(obj.is_palindrome(s))

# Time - O(n), Space O(1)

# This solution uses built-in methods and extra memory

# class Solution:
#     def is_palindrome(self, s: str) -> bool:
#         new_string = ""
#
#         for character in s:
#             if character.isalnum():  # checking if character is alphanumeric
#                 new_string += character.lower()
#
#         return new_string == new_string[::-1]
