# class Solution:
#     def __init__(self):
#         self.stack1 = []
#         self.stack2 = []
#
#     def push(self, x):
#         self.stack1.append(x)
#
#     def pop(self):
#         while self.stack1:
#             self.stack2.append(self.stack1.pop())
#         ans = self.stack2.pop()
#
#         while self.stack2:
#             self.stack1.append(self.stack2.pop())
#
#         return ans
#
#     def peek(self):
#         while self.stack1:
#             self.stack2.append(self.stack1.pop())
#         ans = self.stack2[-1]
#
#         while self.stack2:
#             self.stack1.append(self.stack2.pop())
#
#         return ans
#
#     def empty(self):
#         if not self.stack1 and not self.stack2:
#             return True


# The question ask to implement O(1) operation

class Solution:
    def __init__(self):
        self.stack1 = []
        self.stack2 = []
        self.front = None

    def push(self, x):
        if not self.stack1:
            self.front = x
        self.stack1.append(x)

    def pop(self):
        if not self.stack2:
            while self.stack1:
                self.stack2.append(self.stack1.pop())
        ans = self.stack2.pop()

        return ans

    def peek(self):
        if self.stack2:
            return self.stack2[-1]

        return self.front

    def empty(self):
        return not self.stack1 and not self.stack2
