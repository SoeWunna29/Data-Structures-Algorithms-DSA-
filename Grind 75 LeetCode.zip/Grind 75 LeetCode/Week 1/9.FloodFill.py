from typing import List


class Solution:
    def flood_fill(self, image: List[list[int]], sr: int, sc: int, new_color: int) -> List[list[int]]:
        starting_pixel = image[sr][sc]
        self.dfs(image, sr, sc, new_color, starting_pixel)
        return image

    def dfs(self, image, sr, sc, new_color, starting_pixel):
        if sr < 0 or sr > len(image) - 1 or sc < 0 or sc > len(image[0]) - 1 or image[sr][sc] == new_color or image[sr][sc] != starting_pixel:
            return

        image[sr][sc] = new_color
        self.dfs(image, sr + 1, sc, new_color, starting_pixel)
        self.dfs(image, sr - 1, sc, new_color, starting_pixel)
        self.dfs(image, sr, sc + 1, new_color, starting_pixel)
        self.dfs(image, sr, sc - 1, new_color, starting_pixel)


obj = Solution()
image = [[1, 1, 1], [1, 1, 0], [1, 0, 1]]
new_color = 2
print(obj.flood_fill(image, 1, 1, new_color))
