from typing import List


class Solution:
    def max_profit(self, prices: List[int]) -> int:
        left, right = 0, 1  # Left pointer = Buy, Right pointer = Sell
        max_profit = 0

        while right < len(prices):
            # Profitable?
            if prices[left] < prices[right]:
                profit = prices[right] - prices[left]  # Sell price - buy price
                max_profit = max(max_profit, profit)  # take the new max profit
            else:
                left = right  # move the left pointer to the lowest price if available
            right += 1

        return max_profit


obj = Solution()
prices = [7, 1, 5, 3, 6, 4]
print(obj.max_profit(prices))

# Time - O(n), Space O(1)
