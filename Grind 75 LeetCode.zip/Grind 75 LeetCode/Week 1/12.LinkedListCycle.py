class ListNode:
    def __init__(self, x):
        self.val = x
        self.next = None


class Solution:
    def has_cycle(self, head: ListNode) -> bool:
        slow, fast = head, head

        while fast and fast.next:  # fast pointer should not be null and have next
            slow = slow.next
            fast = fast.next.nxt
            if slow == fast:
                return True

        return False  # no cycle

# Time - O(n)
