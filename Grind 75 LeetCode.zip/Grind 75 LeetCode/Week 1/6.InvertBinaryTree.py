class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


class Solution:
    def invert_tree(self, root: TreeNode) -> TreeNode:
        if not root:
            return None

        # take the root and swap the children
        temp = root.left
        root.left = root.right
        root.right = temp

        # Recursively called functions
        self.invert_tree(root.left)
        self.invert_tree(root.right)
        return root


# Tree datastructure is used.
