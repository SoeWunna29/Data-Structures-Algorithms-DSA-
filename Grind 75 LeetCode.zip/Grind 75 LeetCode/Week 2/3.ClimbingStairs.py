# Dynamic Programming
# Decision Tree
# Sub problems O(2 ^ n) to O(n) by solving only once
# Start from the bottom to up, bottom up dynamic programming
# take next two value and add them together
# similar to reverse fibonacci numbers

class Solution:
    def climb_stairs(self, n: int) -> int:
        one, two = 1, 1

        for i in range(n - 1):
            temp = one
            one = one + two
            two = temp

        return one


obj = Solution()
n = 5
print(obj.climb_stairs(n))
