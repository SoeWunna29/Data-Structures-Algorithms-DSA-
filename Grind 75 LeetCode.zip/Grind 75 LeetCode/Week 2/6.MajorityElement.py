from typing import List


class Solution:  # Hashmap Time - O(1), Space O(n)
    def majority_element(self, nums: List[int]) -> int:
        count = {}
        result, max_count = 0, 0

        for n in nums:
            count[n] = 1 + count.get(n, 0)
            result = n if count[n] > max_count else result
            max_count = max(count[n], max_count)
        return result


class Solution2:  # Time - O(1), Space O(1)
    def majority_element2(self, nums: List[int]) -> int:
        res, count = 0, 0

        for n in nums:
            if count == 0:
                res = n
            count += 1 if n == res else -1
        return res


obj = Solution()
nums = [1, 1, 3, 3]
print(obj.majority_element(nums))
