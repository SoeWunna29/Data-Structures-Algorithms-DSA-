class Solution:
    def can_construct(self, ransom_note: str, magazine: str) -> bool:
        ran = sorted(list(ransom_note))
        mag = sorted(list(magazine))

        for char in mag:
            if ran and char == ran[0]:
                ran.pop(0)
        if ran:
            return False
        else:
            return True


obj = Solution()
ransom_note = "aa"
magazine = "aab"
print(obj.can_construct(ransom_note, magazine))
