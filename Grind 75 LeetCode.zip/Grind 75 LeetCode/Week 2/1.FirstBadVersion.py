def is_bad_version(version):
    return True if version == 3 else False


class Solution:
    def first_bad_version(self, n):
        start = 1
        end = n
        while start < end:
            mid = (start + end) // 2
            if is_bad_version(mid):
                end = mid
            else:
                start = mid + 1
        return start


obj = Solution()
n = 10
print(obj.first_bad_version(n))
