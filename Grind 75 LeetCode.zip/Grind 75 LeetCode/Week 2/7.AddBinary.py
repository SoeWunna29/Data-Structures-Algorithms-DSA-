class Solution:
    def add_binary(self, a: str, b: str) -> str:
        res = ""
        carry = 0

        a, b = a[::-1], b[::-1]

        for i in range(max(len(a), len(b))):
            digit_A = ord(a[i]) - ord("0") if i < len(a) else 0  # ord(a[i]) - ord("0") will give int of string
            digit_B = ord(b[i]) - ord("0") if i < len(b) else 0

            total = digit_A + digit_B + carry
            char = str(total % 2)
            res = char + res
            carry = total // 2

        if carry:
            res = "1" + res
        return res


obj = Solution()
a = "11"
b = "1"
print(obj.add_binary(a, b))
