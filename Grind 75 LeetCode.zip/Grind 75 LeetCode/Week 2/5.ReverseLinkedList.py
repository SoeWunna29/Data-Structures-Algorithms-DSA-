class ListNode:
    def __init__(self, val, next):
        self.val = val
        self.next = next


class Solution:
    def reverse_linked_list(self, head: ListNode) -> ListNode:
        prev = None
        curr = head
        # Time - O(n), Space - O(1)
        while curr:
            nxt = curr.next
            curr.next = prev
            prev = curr
            curr = nxt
        return prev

# if we use recursive, Space - O(n)
#         if not head:
#             return None
#
#         newHead = head
#         if head.next:
#             newHead = self.reverse_linked_list(head.next)
#             head.next.next = newHead
#         head.next = None
#
#         return newHead
