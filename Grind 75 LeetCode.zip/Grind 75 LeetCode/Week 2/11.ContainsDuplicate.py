from typing import List


class Solution:
    def contains_duplicate(self, nums: List[int]) -> bool:
        hashset = set()

        for n in nums:
            if n in hashset:
                return True
            hashset.add(n)
        return False


obj = Solution()
nums = [5, 3, 4, 2, 1, 4, 5]
print(obj.contains_duplicate(nums))
