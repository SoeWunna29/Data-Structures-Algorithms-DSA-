from collections import Counter


class Solution:
    def longest_palindrome(self, s: str) -> int:
        c = Counter(s)  # Count the number of characters and store as a dictionary
        output = 0

        for count in c.values():
            output += int(count / 2) * 2
            if output % 2 == 0 and count % 2 == 1:
                output += 1
        return output


obj = Solution()
s = "aabbcc"
print(obj.longest_palindrome(s))
