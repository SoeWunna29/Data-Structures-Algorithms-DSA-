def print_items(a, b):
    for i in range(a):  # O(a)
        print(i)

    for j in range(b):  # O(b)
        print(j)


print_items(1, 10)

# Different Terms for input
# O(n) + O(m) will be O(n + m)
# For loop is O (n)
# O(a) + O(b), function has two parameters, so the result is O(a + b)


def print_items(a, b):
    for i in range(a):  # O(a)
        for j in range(b):  # O(b)
            print(i, j)

# Nested for loop, O(n^2)
# O(n) * O(n)
# O(a) * O(b)
# O(a * b)
