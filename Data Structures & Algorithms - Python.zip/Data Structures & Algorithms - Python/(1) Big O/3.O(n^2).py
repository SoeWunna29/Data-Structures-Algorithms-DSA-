def print_items(n):
    for i in range(n):  # O(n)
        for j in range(n):  # O(n)
            print(i, j)


print_items(10)

# O(n ^ 2)
# Loop inside a loop, nested loops
# O(n) * O (n)
# Less efficient from time complexity standpoint
