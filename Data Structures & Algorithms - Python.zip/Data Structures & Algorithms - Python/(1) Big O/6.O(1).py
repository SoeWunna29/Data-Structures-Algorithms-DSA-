def add_items(n):
    return n + n + n  # O(1)
 

print(add_items(10))


# O(1), most efficient Big O
# Only one operation is performed
# O(1) is also called constant time
