def print_items(n):
    for i in range(n):  # O(n)
        print(i)

    for j in range(n):  # O(n)
        print(j)


print_items(10)

# Drop Constants
# Instead of O(n) + O(n) = O(2n), we drop constant 2
# The result is also O(n)
