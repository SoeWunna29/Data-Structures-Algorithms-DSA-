items = [1, 2, 3, 4, 5, 6, 7, 8]

# O(log n), divide and conquer
# Dividing list and searching number
# 2 to the WHAT power, log 8 base 2 = 8, 2 to the power 3 times is 8
# O(log n) is the second most efficient after O(1)

# O(n long n) is used for some sorting algorithms
# Merger Sort and Quick Sort
