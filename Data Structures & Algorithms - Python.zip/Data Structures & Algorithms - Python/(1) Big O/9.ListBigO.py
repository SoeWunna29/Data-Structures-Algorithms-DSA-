items = [1, 2, 3, 4, 5, 6, 7, 8]

# Big O of Lists
# append, no reindexing, simple operation, O(1)
# remove/pop, removing from the end, no indexing, simple operation, O(1)

# pop(0), removing item from the start, reindexing required, has to go through the entire list, O(n)
# insert(0, 11), reindexing required, O(n)

# n in this case is number of items in the list

# Removing or adding to the end of the list is O(1)
# Removing or adding to the start of the list is O(n)
# Inserting, O(n)

# Searching item, O(n)
# Searching item by index, O(1)
