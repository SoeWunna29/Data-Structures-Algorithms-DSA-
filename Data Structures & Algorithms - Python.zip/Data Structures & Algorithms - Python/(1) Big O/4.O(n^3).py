def print_items(n):
    for i in range(n):
        for j in range(n):
            for k in range(n):
                print(i, j, k)


print_items(10)

# If there are 3 for loops, Big O will also be O(n ^ 2), not O(n ^ 3)
# We will simplify as O(n ^ 2)
