def print_items(n):
    for i in range(n):  # O(n)
        for j in range(n):  # O(n)
            print(i, j)

    for k in range(n):  # O(n)
        print(k)


print_items(10)

# Dropping Non-Dominants
# Nested for loop O(n ^ 2) + for loop O(n)
# O(n ^ 2 + n)
# We will drop insignificant standalone n
# n is very small portion of n ^ 2
# Drop the n
# The result is also O(n ^ 2)
