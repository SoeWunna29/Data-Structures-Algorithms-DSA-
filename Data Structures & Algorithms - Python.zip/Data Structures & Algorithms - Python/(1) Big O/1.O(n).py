def print_items(n):
    for i in range(n):
        print(i)


print_items(10)


# Big O is a way of comparing two codes how efficiently they run
# Time Complexity is measured in number of operations (not in time)
# Space Complexity
# Three Greek Letters - Omega {Best Case Scenario}, Theta {Average Case}, Omicron (Big O) {Worst Case}
# Whenever we say about Big O, we are talking about worst case

# O(n)
# run n times, n operations
# O(n) is proportional, straight line on graph
