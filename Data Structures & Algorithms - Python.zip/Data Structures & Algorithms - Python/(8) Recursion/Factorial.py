def factorial(n):  # pass a number
    if n == 1:  # check if n is equal to 1
        return 1  # if true, return 1
    return n * factorial(n-1)


print(factorial(4))
# return 4 * factorial(3)
# return 3 * factorial(2)
# return 2 * factorial(1)
# return 1, Last in First out

# 1 -> 2 * 1 -> 3 * 2 -> 4 * 6

# 4! = 4 * 3 * 2 * 1
# 4! = 4 * 3!, 3! = 3 * 2!, 2! = 2 * 1, 1! is 1
