def func_three():
    print('Three')


def func_two():
    func_three()
    print('Two')


def func_one():
    func_two()
    print('One')


func_one()

# A function that calls itself until it doesn't
# def open_gift_box():
#     if True: (if condition)
#         return True (return statement)
#     open_gift_box()
# The process of opening each new box is the same
# Each time we open a box, we make the problem smaller
# if condition has to be true, can result in infinite recursive call and cause stack overflow
# if and return statement must be in the code

# Call Stack
# FuncOne -> FuncTwo -> FuncThree, Stack LIFO (Last in First out)
