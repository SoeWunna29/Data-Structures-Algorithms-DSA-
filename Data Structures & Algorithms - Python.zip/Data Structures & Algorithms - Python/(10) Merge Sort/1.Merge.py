def merge(list1, list2):  # Start with two sorted list
    combined = []  # To combine two sorted list
    i = 0  # points to the index 0 of the first list
    j = 0  # points to the index 0 of the second list
    while i < len(list1) and j < len(list2):  # Run the while loop until one list becomes empty
        if list1[i] < list2[j]:
            combined.append(list1[i])  # adding smaller item to combined list
            i += 1  # moving i over 1
        else:
            combined.append(list2[j])  # adding smaller item to combined list
            j += 1  # moving j over 1

    # if items in list1 remained
    while i < len(list1):  # appending the remaining items in list1
        combined.append(list1[i])
        i += 1
    # if items in list2 remained
    while j < len(list2):  # appending the remaining items in list1
        combined.append(list2[j])
        j += 1

    return combined


print(merge([1, 2, 7, 8], [3, 4, 5, 6]))

# Merge Sort
# It breaks the list into half til only 1 item is left in the list
# Take two item and create a new list sorted
# Then combine sorted lists

# Merge
# Compare items in the two sorted lists and adding smaller item first into a new combined list, then larger
# [1, 3, 4] and [2, 6, 7] -> [1, 2, 3, 4, 6, 7] combined list
