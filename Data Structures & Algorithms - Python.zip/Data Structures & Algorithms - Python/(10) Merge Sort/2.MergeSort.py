def merge(list1, list2):  # Start with two sorted list
    combined = []  # To combine two sorted list
    i = 0  # points to the index 0 of the first list
    j = 0  # points to the index 0 of the second list
    while i < len(list1) and j < len(list2):  # Run the while loop until one list becomes empty
        if list1[i] < list2[j]:
            combined.append(list1[i])  # adding smaller item to combined list
            i += 1  # moving i over 1
        else:
            combined.append(list2[j])  # adding smaller item to combined list
            j += 1  # moving j over 1

    # if items in list1 remained
    while i < len(list1):  # appending the remaining items in list1
        combined.append(list1[i])
        i += 1
    # if items in list2 remained
    while j < len(list2):  # appending the remaining items in list1
        combined.append(list2[j])
        j += 1

    return combined


def merge_sort(my_list):
    if len(my_list) == 1:  # base case
        return my_list
    mid_index = int(len(my_list) / 2)  # split the list in half, int is used for odd number lists
    left = merge_sort(my_list[:mid_index])  # up to mid, not including
    # merge only works on sorted list, called recursion
    # break the list in half until one item remains
    right = merge_sort(my_list[mid_index:])  # from mid to end

    return merge(left, right)  # returning value returned from merge function


original_list = [3, 1, 4, 2]

sorted_list = merge_sort(original_list)

print('Original List: ', original_list)

print('\nSorted List: ', sorted_list)

# Merge Sort
# 1. Break lists in half
# Will use recursion to break the list over and over again
# Breaking things in half means making them smaller and smaller
# 2. Will use recursion until we reach the base case: when len(the_list) is 1
# 3. Use merge() to put list together
# Merge sort is different from other sorting algorithms
# Others sort the list in place, original list will be sorted
# Merge sort, original list remains the same, return separate sorted list

# Big O
# Space complexity, O(n), create new lists
# Time complexity
# Breaking list apart is O(log n), divides and conquer
# Putting them back, O(n)
# Merge Sort - O(n long n), the most efficient algorithm for sorting items
# Other sorts are O(n^2)
