class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert(self, value):
        new_node = Node(value)
        if self.root is None:
            self.root = new_node
            return True
        temp = self.root
        while True:
            if new_node.value == temp.value:
                return False
            if new_node.value < temp.value:
                if temp.left is None:
                    temp.left = new_node
                    return True
                temp = temp.left
            else:
                if temp.right is None:
                    temp.right = new_node
                    return True
                temp = temp.right

    def contains(self, value):
        if self.root is None:
            return False
        temp = self.root
        while temp:
            if value < temp.value:
                temp = temp.left
            elif value > temp.value:
                temp = temp.right
            else:
                return True
        return False

    def BFS(self):
        current_node = self.root  # set current node
        queue = []  # will store the entire node
        results = []  # will store respective value
        queue.append(current_node)  # value, left and right of entire node is added

        while len(queue) > 0:  # will run until the queue is empty
            current_node = queue.pop(0)  # setting current node as first item in the queue
            results.append(current_node.value)  # adding value to results

            if current_node.left is not None:  # checking children node on left
                queue.append(current_node.left)  # adding this node to queue
            if current_node.right is not None:  # checking children node on right
                queue.append(current_node.right)  # adding this node to queue

        return results

    def dfs_pre_order(self):
        results = []  # result list
        # Call stack is also used
        def traverse(current_node):  # Recursive function
            results.append(current_node.value)  # take the value from current node and write it to result

            if current_node.left is not None:
                traverse(current_node.left)
            if current_node.right is not None:
                traverse(current_node.right)

        traverse(self.root)
        return results


my_tree = BinarySearchTree()
my_tree.insert(47)
my_tree.insert(21)
my_tree.insert(76)
my_tree.insert(18)
my_tree.insert(27)
my_tree.insert(52)
my_tree.insert(82)

print(my_tree.dfs_pre_order())

# Depth First Search Pre Order
# Start at root, keep moving to the left as far as we can go
# Come back up and go to right
# After every node to the left of root has been visited, go back to root and visit right
# On the way, visit left first
