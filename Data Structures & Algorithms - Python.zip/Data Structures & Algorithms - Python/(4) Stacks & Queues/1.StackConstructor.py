class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class Stack:  # LIFO, Last in First out
    def __init__(self, value):
        new_node = Node(value)
        self.top = new_node  # Only add from top
        self.height = 1

    def print_stack(self):
        temp = self.top
        while temp is not None:
            print(temp.value)
            temp = temp.next


my_stack = Stack(4)

my_stack.print_stack()

# Adding or removing to/from the end of the list is O(1)
# Adding or removing to/from the front of the list is O(n)
# If you are using list for stack, make sure you add items from O(1) side
# Implement using linked list
# head becomes top, tail is no longer necessary
# Adding (push) to and removing (pop) from stack is O(1)
