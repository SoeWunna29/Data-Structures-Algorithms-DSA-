class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class Queue:  # FIFO, Fast in First out
    def __init__(self, value):
        new_node = Node(value)
        self.first = new_node
        self.last = new_node
        self.length = 1

    def print_queue(self):
        temp = self.first
        while temp is not None:
            print(temp.value)
            temp = temp.next


my_queue = Queue(4)

my_queue.print_queue()

# In linked list, removing from end is O (n) and adding it back is O(1)
# Other end, both O(1)
# Don't want to dequeue from O(n) side
# In queue, head becomes first and tail becomes last
