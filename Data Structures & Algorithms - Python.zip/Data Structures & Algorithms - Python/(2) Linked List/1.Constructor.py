class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self, value):
        new_node = Node(value)
        self.head = new_node
        self.tail = new_node
        self.length = 1


my_linked_list = LinkedList(4)
print(my_linked_list.head.value)

# Append, O(1)
# Remove, O(n)
# Prepend, adding from front, O(1)
# Pop first, removing from front, O(1)
# Adding item in the middle, O(n)
# Looking up by value or index, O(n)
