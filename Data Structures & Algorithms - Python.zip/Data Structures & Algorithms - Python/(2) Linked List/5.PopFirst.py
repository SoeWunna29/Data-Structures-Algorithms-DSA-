class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self, value):
        new_node = Node(value)
        self.head = new_node
        self.tail = new_node
        self.length = 1

    def print_list(self):
        temp = self.head
        while temp is not None:
            print(temp.value)
            temp = temp.next

    def append(self, value):
        new_node = Node(value)
        if self.length == 0:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
        self.length += 1
        return True

    # Removing or Popping a Node at the End of a Linked List
    def pop(self):
        if self.length == 0:
            return None

        temp = self.head  # define two pointer variables temp and pre
        pre = self.head

        while temp.next:  # if temp.next is not none
            pre = temp
            temp = temp.next  # move temp pointer to next node

        self.tail = pre  # the purpose of pre value is to track tail
        self.tail.next = None  # removing node at the end of the list (pop)
        self.length -= 1

        if self.length == 0:  # Edge case, if only *one node is available in the linked list
            self.head = None
            self.tail = None
        return temp  # return temp.value (for testing purpose)

    # Adding or Appending a Node at the Start/Beginning of the Linked List
    def prepend(self, value):
        new_node = Node(value)
        if self.length == 0:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node
        self.length += 1
        return True

    # Popping or Removing of the First Node in a Linked List
    def pop_first(self):
        if self.length == 0:
            return None
        temp = self.head
        self.head = self.head.next
        temp.next = None
        self.length -= 1
        if self.length == 0:  # After decrementing the length of the linked list
            self.tail = None
        return temp  # return temp.value for testing


my_linked_list = LinkedList(2)
my_linked_list.append(1)

# (2) Items - Returns 2 Node
print(my_linked_list.pop_first())
# (1) Item - Returns 1 Nonde
print(my_linked_list.pop_first())
# (0) Items - Returns None
print(my_linked_list.pop_first())
