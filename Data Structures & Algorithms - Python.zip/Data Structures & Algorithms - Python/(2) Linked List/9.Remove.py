class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self, value):
        new_node = Node(value)
        self.head = new_node
        self.tail = new_node
        self.length = 1

    def print_list(self):
        temp = self.head
        while temp is not None:
            print(temp.value)
            temp = temp.next

    def append(self, value):
        new_node = Node(value)
        if self.length == 0:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
        self.length += 1
        return True

    # Removing or Popping a Node at the End of a Linked List
    def pop(self):
        if self.length == 0:
            return None

        temp = self.head  # define two pointer variables temp and pre
        pre = self.head

        while temp.next:  # if temp.next is not none
            pre = temp
            temp = temp.next  # move temp pointer to next node

        self.tail = pre  # the purpose of pre value is to track tail
        self.tail.next = None  # removing node at the end of the list (pop)
        self.length -= 1

        if self.length == 0:  # Edge case, if only *one node is available in the linked list
            self.head = None
            self.tail = None
        return temp  # return temp.value (for testing purpose)

    # Adding or Appending a Node at the Start/Beginning of the Linked List
    def prepend(self, value):
        new_node = Node(value)
        if self.length == 0:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node
        self.length += 1
        return True

    # Popping or Removing of the First Node in a Linked List
    def pop_first(self):
        if self.length == 0:
            return None
        temp = self.head
        self.head = self.head.next
        temp.next = None
        self.length -= 1
        if self.length == 0:  # After decrementing the length of the linked list
            self.tail = None
        return temp  # return temp.value for testing

    # Getting a Node from a Linked List
    def get(self, index):
        if index < 0 or index >= self.length:
            return None
        temp = self.head
        for _ in range(index):
            temp = temp.next
        return temp

    # Setting Value of a Node in a Linked List
    def set_value(self, index, value):
        temp = self.get(index)
        if temp:  # checking if temp is not none or temp is pointing to a node
            temp.value = value
            return True
        return False

    # Inserting a Node in a Linked List
    def insert(self, index, value):
        if index < 0 or index > self.length:
            return False

        if index == 0:  # Index 0 means adding to the start of the linked list
            return self.prepend(value)

        if index == self.length:  # length - 1 is index of last element, so length is last index + 1
            return self.append(value)

        new_node = Node(value)
        temp = self.get(index - 1)  # a variable to point the node before the index where we're gonna insert
        new_node.next = temp.next  # setting new node next by replacing temp node next
        temp.next = new_node  # let temp node next be new node
        self.length += 1
        return True

    # Removing a Node by an Index from a Linked List
    def remove(self, index):
        if index < 0 or index >= self.length:
            return None  # None would be the opposite of removing a node

        if index == 0:  # Removing first node is same a pop_first
            return self.pop_first()

        if index == self.length - 1:  # length - 1 is index of last element
            return self.pop()

        pre = self.get(index - 1)  # variable to point a node before the item we want to remove
        temp = pre.next
        pre.next = temp.nxt  # removing temp from the linked list
        temp.nxt = None  # removing temp from list
        self.length -= 1
        return temp


my_linked_list = LinkedList(11)
my_linked_list.append(3)
my_linked_list.append(23)
my_linked_list.append(7)

print(my_linked_list.remove(2), '\n')

my_linked_list.print_list()
