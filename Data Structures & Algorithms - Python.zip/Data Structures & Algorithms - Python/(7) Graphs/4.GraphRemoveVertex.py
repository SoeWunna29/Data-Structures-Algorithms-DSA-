class Graph:
    def __init__(self):
        self.adj_list = {}  # adjacency list, dictionary

    def print_graph(self):
        for vertex in self.adj_list:
            print(vertex, ":", self.adj_list[vertex])  # vertex is key, adj_list[vertex] is value

    def add_vertex(self, vertex):
        if vertex not in self.adj_list.keys():  # Don't want duplicate
            self.adj_list[vertex] = []  # Passing vertex as key and storing an empty list as a value
            return True
        return False

    def add_edge(self, v1, v2):  # adding two vertexes that we want an edge between
        if v1 in self.adj_list and v2 in self.adj_list:  # both vertexes have to be in adj_list
            self.adj_list[v1].append(v2)  # adj_list[v1] is a list/value, appending v2 to that list
            self.adj_list[v2].append(v1)
            return True
        return False

    def remove_edge(self, v1, v2):
        if v1 in self.adj_list and v2 in self.adj_list:  # both vertexes have to be in adj_list
            try:  # Edge case, if a vertex has no edges
                self.adj_list[v1].remove(v2)  # adj_list[v1] is a list/value, removing v2 from that list
                self.adj_list[v2].remove(v1)
            except ValueError:
                pass  # Ignore the error and move on
            return True
        return False

    def remove_vertex(self, vertex):  # we need to remove all the edges before removing a vertex
        if vertex in self.adj_list:
            for other_vertex in self.adj_list[vertex]:  # all edges associated with that vertex
                self.adj_list[other_vertex].remove(vertex)
            del self.adj_list[vertex]  # deleting the vertex
            return True
        return False


my_graph = Graph()

my_graph.add_vertex("A")
my_graph.add_vertex("B")
my_graph.add_vertex("C")
my_graph.add_vertex("D")

my_graph.add_edge("A", "B")
my_graph.add_edge("A", "C")
my_graph.add_edge("A", "D")
my_graph.add_edge("B", "D")
my_graph.add_edge("C", "D")

my_graph.remove_vertex("D")

my_graph.print_graph()
