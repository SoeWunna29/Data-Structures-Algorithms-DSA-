class Graph:
    def __init__(self):
        self.adj_list = {}  # adjacency list, dictionary

    def print_graph(self):
        for vertex in self.adj_list:
            print(vertex, ":", self.adj_list[vertex])  # vertex is key, adj_list[vertex] is value

    def add_vertex(self, vertex):
        if vertex not in self.adj_list.keys():  # Don't want duplicate
            self.adj_list[vertex] = []  # Passing vertex as key and storing an empty list as a value
            return True
        return False


my_graph = Graph()

my_graph.add_vertex('A')

my_graph.print_graph()

# Graph
# Vertex is node
# Between two vertexes is Edge or Connection, edges are weighted or have costs
# A vertex can connect to unlimited vertexes

# Adjacency Matrix, symmetric (bidirectional)
# Adjacency List, can represent as dictionary {'A':['B', 'E'], 'B':['A', 'E']}

# Big O
# Space Complexity - AM O(|V| ^ 2), AL O(|v| + |E|)
# Time Complexity
# Adding vertex, AM O(V ^ 2), AL O(1), V is vertex (n), Adjacency List is better
# Adding Edge, AM O(1), AL O(1)
# Removing Edge, AM O(1), AL O(|E|), E is edges (n)
# Remove Vertex, AM O(|V| ^ 2), AL O(|v| + |E|)
# AM is bad for space because it stores all zeros
