class Graph:
    def __init__(self):
        self.adj_list = {}  # adjacency list, dictionary

    def print_graph(self):
        for vertex in self.adj_list:
            print(vertex, ":", self.adj_list[vertex])  # vertex is key, adj_list[vertex] is value

    def add_vertex(self, vertex):
        if vertex not in self.adj_list.keys():  # Don't want duplicate
            self.adj_list[vertex] = []  # Passing vertex as key and storing an empty list as a value
            return True
        return False

    def add_edge(self, v1, v2):  # adding two vertexes that we want an edge between
        if v1 in self.adj_list and v2 in self.adj_list:  # both vertexes have to be in adj_list
            self.adj_list[v1].append(v2)  # adj_list[v1] is a list/value
            self.adj_list[v2].append(v1)
            return True
        return False


my_graph = Graph()

my_graph.add_vertex(1)
my_graph.add_vertex(2)

my_graph.add_edge(1, 2)

my_graph.print_graph()
