class HashTable:
    def __init__(self, size=7):  # Should always have a prime number [0, 1, 2 , 3, 4, 5 , 6]
        # Prime number increases the chance of randomness, so collision is reduced.
        self.data_map = [None] * size  # Creating a list with 7 items in it

    def print_table(self):
        for i, val in enumerate(self.data_map):  # i is iteration, val is value in data map
            print(i, ": ", val)

    # Hash method
    def __hash(self, key):
        my_hash = 0
        for letter in key:
            my_hash = (my_hash + ord(letter) * 23) % len(self.data_map)
            # ord gets the ASCII number (numerical value) for each letter
            # using 23 is a prime number, any prime number can be used
            # % length of data map, remainder will be any number from zero to 6, it will be address space
        return my_hash

    def set_item(self, key, value):
        index = self.__hash(key)  # passing the key to has function, it will compute the address

        if self.data_map[index] == None:  # will create an empty list at the index only if it is none
            self.data_map[index] = []  # create an empty list at the index

        self.data_map[index].append([key, value])

    def get_item(self, key):
        index = self.__hash(key)  # figure out the index for that key

        if self.data_map[index] is not None:  # checking the index whether it is none
            for i in range(len(self.data_map[index])):  # Loop through the items in that address
                # [i][0] is checking the keys in the list
                if self.data_map[index][i][0] == key:  # [i] items index (from for loop), [0] - key index
                    return self.data_map[index][i][1]  # [1] - value
        return None


my_hash_table = HashTable()

my_hash_table.set_item('bolts', 1400)
my_hash_table.set_item('washers', 50)

print(my_hash_table.get_item('bolts'))
print(my_hash_table.get_item('washers'))
print(my_hash_table.get_item('lumber'))
