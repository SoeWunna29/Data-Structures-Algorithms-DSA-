def item_in_common(list1, list2):
    my_dict = {}
    for i in list1:  # O(n)
        my_dict[i] = True  # adding key and value to dictionary

    for j in list2:  # O(n)
        if j in my_dict:  # checking common item
            return True

    return False

# Result O(n) + O(n) = O(n), it is more efficient than O(n ^ 2)


list1 = [1, 3, 5]
list2 = [2, 4, 5]

print(item_in_common(list1, list2))


# We can use nested for loop to solve this problem. But O(n ^ 2)
# def item_in_common_slow(list1, list2):
#     for i in list1:
#         for j in list2:
#             if i == j:
#                 return True
#     return False
