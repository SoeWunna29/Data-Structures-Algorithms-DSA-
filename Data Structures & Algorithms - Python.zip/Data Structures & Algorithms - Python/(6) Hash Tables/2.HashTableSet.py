class HashTable:
    def __init__(self, size=7):  # Should always have a prime number [0, 1, 2 , 3, 4, 5 , 6]
        # Prime number increases the chance of randomness, so collision is reduced.
        self.data_map = [None] * size  # Creating a list with 7 items in it

    def print_table(self):
        for i, val in enumerate(self.data_map):  # i is iteration, val is value in data map
            print(i, ": ", val)

    # Hash method
    def __hash(self, key):
        my_hash = 0
        for letter in key:
            my_hash = (my_hash + ord(letter) * 23) % len(self.data_map)
            # ord gets the ASCII number (numerical value) for each letter
            # using 23 is a prime number, any prime number can be used
            # % length of data map, remainder will be any number from zero to 6, it will be address space
        return my_hash

    def set_item(self, key, value):
        index = self.__hash(key)  # passing the key to has function, it will compute the address

        if self.data_map[index] == None:  # will create an empty list at the index only if it is none
            self.data_map[index] = []  # create an empty list at the index

        self.data_map[index].append([key, value])


my_hash_table = HashTable()

my_hash_table.set_item('bolts', 1400)
my_hash_table.set_item('washers', 50)
my_hash_table.set_item('lumber', 70)

my_hash_table.print_table()
