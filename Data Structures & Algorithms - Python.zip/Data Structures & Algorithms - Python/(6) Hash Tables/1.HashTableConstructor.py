class HashTable:
    def __init__(self, size=7):  # Should always have a prime number [0, 1, 2 , 3, 4, 5 , 6]
        # Prime number increases the chance of randomness, so collision is reduced.
        self.data_map = [None] * size  # Creating a list with 7 items in it

    def print_table(self):
        for i, val in enumerate(self.data_map):  # i is iteration, val is value in data map
            print(i, ": ", val)

    # Hash method
    def __hash(self, key):
        my_hash = 0
        for letter in key:
            my_hash = (my_hash + ord(letter) * 23) % len(self.data_map)
            # ord gets the ASCII number (numerical value) for each letter
            # using 23 is a prime number, any prime number can be used
            # % length of data map, remainder will be any number from zero to 6, it will be address space
        return my_hash


my_hash_table = HashTable()

my_hash_table.print_table()

# Build in hash table - dictionary (Key: Value)
# Take the key and hash, we get the address and store at that address
# 1.Hash is one way only
# 2.Hash is deterministic (particular hash function), it means we know the address

# If collision occurs at the same address, both stored as another list (Separate Chaining)
# If collision occurs at the same address, move to next empty address (Linear Probing), open addressing

# Separate Chaining, instead of storing collided items as a list, we will use linked list
