def swap(my_list, index1, index2):  # To swap numbers
    temp = my_list[index1]
    my_list[index1] = my_list[index2]
    my_list[index2] = temp


def pivot (my_list, pivot_index, end_index):
    swap_index = pivot_index  # swap index will be set as pivot index

    for i in range(pivot_index + 1, end_index + 1):  # i will start after pivot index, up to + 1
        if my_list[i] < my_list[pivot_index]:
            swap_index += 1  # move swap index
            swap(my_list, swap_index, i)  # swap the items at i and at swap index

    swap(my_list, pivot_index, swap_index)  # swap the item at pivot index and at swap index
    return swap_index


def quick_sort_helper(my_list, left, right):  # leftmost index and rightmost index
    if left < right:  # base case
        pivot_index = pivot(my_list, left, right)  # calling pivot function
        # will call quick sort function recursively
        quick_sort_helper(my_list, left, pivot_index - 1)  # from start up to pivot index - 1
        quick_sort_helper(my_list, pivot_index + 1, right)  # from pivot index + 1 to right
    return my_list


def quick_sort(my_list):  # To avoid passing left and right value
    return quick_sort_helper(my_list, 0, len(my_list) - 1)


print(quick_sort([4, 6, 1, 7, 3, 2, 5]))

# Quick Sort
# Will run pivot function recursively on smaller side and larger side

# Big O
# O(n log n) is just for best case and average case
# Worst case - O(n ^ 2) if you have already sorted data
