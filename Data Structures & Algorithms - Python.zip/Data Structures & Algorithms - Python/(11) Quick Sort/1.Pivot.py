def swap(my_list, index1, index2):  # To swap numbers
    temp = my_list[index1]
    my_list[index1] = my_list[index2]
    my_list[index2] = temp


def pivot (my_list, pivot_index, end_index):
    swap_index = pivot_index  # swap index will be set as pivot index

    for i in range(pivot_index + 1, end_index + 1):  # i will start after pivot index, up to + 1
        if my_list[i] < my_list[pivot_index]:
            swap_index += 1  # move swap index
            swap(my_list, swap_index, i)  # swap the items at i and at swap index

    swap(my_list, pivot_index, swap_index)  # swap the item at pivot index and at swap index
    return swap_index


my_list = [4, 6, 1, 7, 3, 2, 5]

print(pivot(my_list, 0, 6))  # swap index is returned

print(my_list)  # smaller - pivot - larger

# Pivot, helper function
# pick a pivot point
# Smaller items will be put on left side of pivot point, larger on the right

# Quick Sort
# Start with the pivot point
# Compare each of the item after it
