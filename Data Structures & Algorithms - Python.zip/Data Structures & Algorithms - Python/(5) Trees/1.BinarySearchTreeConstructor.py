class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None  # Creating an empty tree at the time we run the constructor


my_tree = BinarySearchTree()  # we will use insert method to add nodes to the empty tree later

print(my_tree.root)

# Binary Tree
# Full Tree - Every node either points to zero node or two nodes
# Perfect Tree - Any level, any node is completely filled all the way across
# Complete Tree - Left to right with no gaps
# Every node can only have one parent node
# Nodes that don't have children are called leaves

# Binary Search Tree - the nodes have to be laid out in a particular way
# If the number is greater than root, move to the right of the root
# If the number is less than root, move to the left
# Start comparing from the top
# If there is a node already there, compare a new node with that node again
# All nodes below it to the right will be greater than that node
# Every node to the left will be less than that node

# Big O
# Looking for a node in a BST, O(log n) (divide and conquer)
# but in worst case O(n) if the tree is like linked list, only have nodes to one side
# But we will treat it a O(long n) for lookup(), insert(), remove()
