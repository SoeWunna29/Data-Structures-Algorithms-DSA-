class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None  # Creating an empty tree at the time we run the constructor

    def insert(self, value):
        new_node = Node(value)
        if self.root is None:  # Empty tree, inserting a new node is like adding root node
            self.root = new_node
            return True

        temp = self.root  # To declare the variable
        while True:  # Go through again and again
            if new_node.value == temp.value:  # Can't have duplicates
                return False

            if new_node.value < temp.value:  # Go left if the value is less than temp node
                if temp.left is None:  # Spot is open
                    temp.left = new_node
                    return True  # Operation is done
                temp = temp.left  # Go further left if the spot is not open

            else:  # Go right is the value is greater than temp node
                if temp.right is None:  # Spot is open
                    temp.right = new_node
                    return True  # Operation is done
                temp = temp.right  # Go further right is the spot is not open

    def contains(self, value):
        temp = self.root
        while temp is not None:  # Traversing through the tree
            if value < temp.value:  # Less than temp value, left
                temp = temp.left
            elif value > temp.value:  # Greater than temp value, right
                temp = temp.right
            else:  # Found the number when value is equal to temp
                return True
        return False

    def min_value_node(self, current_node):
        while current_node.left is not None:  # Left of current_node is not none
            current_node = current_node.left  # Making current node = current node left
        return current_node  # Will return current node as min node when it can't go lower anymore


my_tree = BinarySearchTree()
my_tree.insert(47)
my_tree.insert(21)
my_tree.insert(76)
my_tree.insert(18)
my_tree.insert(27)
my_tree.insert(52)
my_tree.insert(82)

print(my_tree.min_value_node(my_tree.root))

print(my_tree.min_value_node(my_tree.root.right))
