class Node:
    def __init__(self, value):
        self.value = value
        self.next = None
        self.prev = None


class DoublyLinkedList:
    def __init__(self, value):
        new_node = Node(value)
        self.head = new_node
        self.tail = new_node
        self.length = 1

    def print_list(self):
        temp = self.head
        while temp is not None:
            print(temp.value)
            temp = temp.next

    def append(self, value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            new_node.prev = self.tail # Has to point the previous node in Doubly linked List
            self.tail = new_node
        self.length += 1
        return True

    # Don't need to loop through the entire list for doubly linked list, like we do in linked list
    def pop(self):
        if self.length == 0:
            return None

        temp = self.tail
        if self.length == 1:  # if only one node exists in doubly linked list
            self.head = None
            self.tail = None
        else:
            self.tail = self.tail.prev
            # Removing temp node by setting next and prev to None
            self.tail.next = None
            temp.prev = None
        self.length -= 1
        return temp

    def prepend(self, value):
        new_node = Node(value)
        if self.length == 0:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head  # Pointing new node next to existing head
            self.head.prev = new_node  # Pointing prev from head to new node
            self.head = new_node  # Setting new node as head
        self.length += 1
        return True

    def pop_first(self):
        if self.length == 0:
            return None

        temp = self.head  # temp variable to point the head
        if self.length == 1:  # Only 1 item in the doubly linked list
            self.head = None
            self.tail = None
        else:
            self.head = self.head.nxt  # Setting head node to the next node
            self.head.prev = None  # Removing previous pointer to head
            temp.next = None  # Removing temp next pointer to head
        self.length -= 1
        return temp

    def get(self, index):
        if index < 0 or index >= self.length:
            return None

        temp = self.head  # Forward
        if index < self.length/2:  # Searching 1st half
            for _ in range(index):
                temp = temp.next  # Forwarding from head
        else:
            temp = self.tail  # Backward
            for _ in range(self.length - 1, index, -1):  # Searching 2nd half (start, stop, decrement)
                temp = temp.prev  # Reversing from tail
        return temp

    def set_value(self, index, value):
        temp = self.get(index)
        if temp:
            temp.value = value
            return True
        return False


my_doubly_linked_list = DoublyLinkedList(11)
my_doubly_linked_list.append(3)
my_doubly_linked_list.append(23)
my_doubly_linked_list.append(7)

my_doubly_linked_list.set_value(1, 4)

my_doubly_linked_list.print_list()
