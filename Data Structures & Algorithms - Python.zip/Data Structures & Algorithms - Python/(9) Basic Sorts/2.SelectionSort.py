def selection_sort(my_list):
    for i in range(len(my_list) - 1):  # Loop through the list
        min_index = i  # setting initial minimum index according to i value
        for j in range(i + 1, len(my_list)):  # compare with all other items *after that in the list
            if my_list[j] < my_list[min_index]:  # comparing and switching indexes if it is necessary
                min_index = j
        if i != min_index:  # Only when we have items to be swapped
            # Swapping two items in the list
            temp = my_list[i]
            my_list[i] = my_list[min_index]
            my_list[min_index] = temp
    return my_list


print(selection_sort([4, 2, 6, 5, 1, 3]))

# Selection Sort
# We need indexes for selection sort
# Select first item, store its index as min index = 0
# Move to second, if second is less than first, store its index as min index = 1, etc.
# Then we will get the minimum number and its index in the list, switch it with min index
# Then move to next item and store its index as min index
