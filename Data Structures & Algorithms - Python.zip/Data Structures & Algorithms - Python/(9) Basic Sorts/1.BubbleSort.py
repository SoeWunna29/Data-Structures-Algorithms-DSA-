def bubble_sort(my_list):
    for i in range(len(my_list) - 1, 0, -1):  # From 5, To 0, Decrement each time
        for j in range(i):  # For loop that is moving forward through the list
            # we will do our comparison in this for loop
            if my_list[j] > my_list[j + 1]:  # eg: if first item is greater than second
                temp = my_list[j]  # container variable to temporarily store larger item
                my_list[j] = my_list[j + 1]  # eg: moving larger second item to first place
                my_list[j + 1] = temp  # putting back smaller item in temp to second place
    return my_list


print(bubble_sort([4, 2, 6, 5, 1, 3]))

# Bubble Sort
# Start with the first item in the list
# Compare with the second item, if first item is larger, switch first with the second one
# Compare second and third, if third is larger, switch second with third
# And largest item will be bubbled up, at the end of the list
# If there are 6 items in the list, we need to do 5 comparisons
