def insertion_sort(my_list):
    for i in range(1, len(my_list)):  # Start at the index of 1, second item in the list
        temp = my_list[i]  # variable to hold that item
        j = i - 1  # item before it
        while temp < my_list[j] and j > -1:
            # while current item is less than item before it and index of before item is greater than -1
            my_list[j + 1] = my_list[j]  # current item takes before item's spot
            my_list[j] = temp  # before item takes current item's spot
            j -= 1  # then continue to compare with items on the left
    return my_list


print(insertion_sort([4, 2, 6, 5, 1, 3]))

# Insertion Sort
# We always start with the second item in the list, compare with the item before
# If item before is less than current item, swap

# Big O
# Worst case - O(n ^ 2)
# Best case  - O(n)
